<?php 
  require_once('header.php'); 
?>
<div style="clear: both;"></div>
<div style="float: left;">
<iframe src="http://wpinternallinks.com/splash.html" width="717" height="500"> </iframe>
</div>