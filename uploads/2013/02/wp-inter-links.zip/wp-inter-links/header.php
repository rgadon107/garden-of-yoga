<link rel="stylesheet" type="text/css" media="all" href="<?php echo INLPLN1 ?>css/style.css" />
<div class="inlheader"  align="center" style="float: left;">
<div align="center" style="float: left;">
<img src="<?php echo INLPLN1?>images/Hub.png" border="0"/><br /><strong >Hub</strong> </div>
<div align="center" style="float: left;">
<img src="<?php echo INLPLN1?>images/Ring.png" border="0"/><br /><strong>Ring</strong> </div> 
<div align="center" style="float: left;">
<img src="<?php echo INLPLN1?>images/Web.png" border="0"/><br /><strong>Web</strong> </div>  
<div align="center" style="float: left;">
<img src="<?php echo INLPLN1?>images/Star.png" border="0"/><br /><strong>Star</strong> </div>  
<div align="center" style="float: left;">
<img src="<?php echo INLPLN1?>images/Legend.png" border="0"/><br /><strong>Legend</strong> </div>  
</div>
<div style="clear: both !important;"></div>